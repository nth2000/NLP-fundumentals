if __name__ == '__main__':
    open("wiki.txt")